function Footer() {
    return (
        <footer className="footer">
      <img src="../assets/react.png" alt="React" className="logo small" />
      <p>Powered by React & Murgo</p>
    </footer>
    )
}
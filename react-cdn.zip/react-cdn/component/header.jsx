function Header() {
    return (
        <header className="header">
      <img src="../assets/murgo.png" alt="Murgo" className="logo" />
      <h1>Murgo Counter App</h1>
    </header>
    )
}
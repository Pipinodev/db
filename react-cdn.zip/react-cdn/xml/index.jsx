function App() {
    const [count, setCount] = React.useState(0);
    
    return (
        <div className="app">
            <Header />
            <main>
                <h2>Count: {count}</h2>
                <button className="murgo-btn" onClick={() => setCount(count + 1)}>
                    Increase
                </button>
                <button className="murgo-btn" onClick={() => setCount(0)}>
                    Reset
                </button>
                <button className="murgo-btn" onClick={() => setCount(count - 1)}>
                    Decrease
                </button>
            </main>
            <Footer />
        </div>
    );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
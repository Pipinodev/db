const dson = "../dependencies.json";

(async function() {
    let res = await fetch(dson);
    let json = await res.json();
    let comps = json.components;
    
    for (let i = 0; i < comps.length; i++) {
        let v = comps[i];
        let mv = "../component/" + v + ".jsx";
        
        let sc = document.createElement("script");
        sc.type = "text/babel";
        sc.src = mv;
        document.head.appendChild(sc);
    }
})();